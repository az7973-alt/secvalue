#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if [[ ! -x .venv/bin/python ]]; then python3 -m venv .venv; fi
.venv/bin/python -m pip install --disable-pip-version-check --no-cache-dir -r requirements.txt
exec .venv/bin/python -m secvalue.server --import-workbook data/source.xlsx
