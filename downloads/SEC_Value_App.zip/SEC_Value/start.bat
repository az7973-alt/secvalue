@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe py -3 -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install --disable-pip-version-check --no-cache-dir -r requirements.txt
if errorlevel 1 goto failed
echo Open http://127.0.0.1:8000 in your browser after startup.
.venv\Scripts\python.exe -m secvalue.server --import-workbook data/source.xlsx
if errorlevel 1 goto failed
exit /b 0
:failed
echo Setup failed. See the error above.
pause
exit /b 1
