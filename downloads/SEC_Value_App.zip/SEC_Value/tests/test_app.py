import copy,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from secvalue import store
from secvalue.engine import analyze,parse
from secvalue.providers import csv_import,financial,refresh,quote
class WorkbookTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.c=store.connect();cls.rates={r['cell']:r['value'] for r in cls.c.execute('select * from rates')}
    @classmethod
    def tearDownClass(cls):cls.c.close()
    def record(self,ticker):
        r=self.c.execute('select * from records where ticker=?',(ticker,)).fetchone()
        b=json.loads(r['body']);m=json.loads(self.c.execute('select body from market where ticker=?',(ticker,)).fetchone()[0]);f=json.loads(self.c.execute('select body from financials where ticker=?',(ticker,)).fetchone()[0]);return b,m,f
    def test_all_months_and_duplicates_preserved(self):
        report=store.meta(self.c,'import');self.assertEqual(set(report['sheets']),set('JAN FEB MAR APR MAY JUN JUL AUG SEP OCT NOV DEC'.split()));self.assertEqual(report['records'],4418);self.assertEqual(self.c.execute('select count(distinct ticker) from records').fetchone()[0],4417)
    def test_valuation_matches_workbook_and_linked_rates_change_it(self):
        for t in ['TPL','VRSN','DPZ','MA','NVDA','MSFT','AAPL']:
            b,m,f=self.record(t);a=analyze(b,m,f,self.rates);col=next(k for k,v in b['headers'].items() if v=='Value');self.assertAlmostEqual(a['value'],b['cells'][col]['v'],places=8)
        b,m,f=self.record('TPL');before=analyze(b,m,f,self.rates);rates={**self.rates,'C4':.12};after=analyze(b,m,f,rates);self.assertNotEqual(before['value'],after['value']);self.assertNotEqual(before['r3'],after['r3'])
    def test_direct_rate_preserved(self):
        b,m,f=self.record('NVDA');a=analyze(b,m,f,self.rates);z=analyze(b,m,f,{**self.rates,'C4':.3});self.assertEqual(a['r3'],z['r3']);self.assertEqual(a['value'],z['value'])
    def test_quote_refresh_changes_valuation_share_count_and_price(self):
        b,m,f=self.record('TPL');a=analyze(b,m,f,self.rates);new={**m,'price':m['price']*2,'shares':m['shares']*2};z=analyze(b,new,f,self.rates);self.assertNotEqual(a['bps'],z['bps']);self.assertEqual(z['price'],m['price']*2)
    def test_new_period_not_mixed_into_old_valuation(self):
        b,m,f=self.record('TPL');f['as_of']='2026-09-30';a=analyze(b,m,f,self.rates);self.assertIsNone(a['value']);self.assertTrue(a['period_mismatch'])
    def test_no_arbitrary_formula_execution(self):
        with self.assertRaises(Exception):parse('=__import__("os").system("id")')
class ImportAndProviderTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.patch=patch.object(store,'DB',Path(self.tmp.name)/'test.sqlite');self.patch.start();c=store.connect();c.execute('insert into rates values (?,?,?,?)',('C4','AA',.0527,'original'));c.execute('insert into watch values (?,?)',('TEST','test'));store.put(c,'market','TEST',{'price':10,'market_cap':1000,'shares':100,'source':'old'});c.commit();c.close()
    def tearDown(self):self.patch.stop();self.tmp.cleanup()
    def test_csv_transaction_and_units(self):
        csv_import('market','ticker,price,market_cap,shares,as_of\nTEST,20,2000,100,2026-01-31\n');c=store.connect();self.assertEqual(json.loads(c.execute('select body from market').fetchone()[0])['market_cap'],2000);c.close()
        with self.assertRaises(ValueError):csv_import('market','ticker,price,market_cap,shares,as_of\nTEST,30,3000,100,2026-02-28\nINVALID,0,0,0,2026-02-28\n')
        c=store.connect();self.assertEqual(json.loads(c.execute('select body from market where ticker="TEST"').fetchone()[0])['price'],20);c.close()
    def test_invalid_rates_rejected_and_valid_rate_applied(self):
        with self.assertRaises(ValueError):csv_import('rates','cell,value,as_of\nC4,5,2026-01-31\n')
        csv_import('rates','cell,value,as_of\nC4,.06,2026-01-31\n');c=store.connect();self.assertEqual(c.execute('select value from rates').fetchone()[0],.06);c.close()
    def test_sec_balance_and_period_validation(self):
        header='ticker,assets,equity,intangibles,revenue,receivables,inventory,liabilities,net_income,operating_income,period_start,as_of\n'
        csv_import('sec',header+'TEST,100,40,2,30,5,3,60,4,6,2026-01-01,2026-06-30\n');c=store.connect();self.assertEqual(json.loads(c.execute('select body from financials').fetchone()[0])['cells']['D'],100);c.close()
        with self.assertRaises(ValueError):csv_import('sec',header+'TEST,100,40,2,30,5,3,10,4,6,2026-01-01,2026-06-30\n')
    @patch.dict(os.environ,{'FMP_API_KEY':'','SEC_USER_AGENT':''})
    def test_missing_credentials_do_not_overwrite_existing_data(self):
        result=refresh();self.assertTrue(all(r['status']=='error' for r in result['results']));c=store.connect();self.assertEqual(json.loads(c.execute('select body from market').fetchone()[0])['price'],10);self.assertEqual(c.execute('select count(*) from logs').fetchone()[0],2);c.close()
    def test_sec_same_filing_ytd_mapping_and_missing_metric_hold(self):
        tags={'Assets':100,'StockholdersEquity':40,'GoodwillAndIntangibleAssetsNet':2,'RevenueFromContractWithCustomerExcludingAssessedTax':30,'AccountsReceivableNetCurrent':5,'InventoryNet':3,'Liabilities':60,'NetIncomeLoss':4,'OperatingIncomeLoss':6}
        facts={}
        for tag,value in tags.items():
            v={'val':value*1e6,'end':'2026-06-30','accn':'test-accession','form':'10-Q','filed':'2026-07-20'}
            if tag in ('RevenueFromContractWithCustomerExcludingAssessedTax','NetIncomeLoss','OperatingIncomeLoss'):v['start']='2026-01-01'
            facts[tag]={'units':{'USD':[v]}}
        with patch('secvalue.providers.get_json',return_value={'entityName':'Test','facts':{'us-gaap':facts}}):
            f=financial('TEST',{'0':{'ticker':'TEST','cik_str':123}},'Test test@example.org')
            self.assertEqual(f['cells']['G'],30);self.assertEqual(f['period_start'],'2026-01-01')
            del facts['InventoryNet']
            with self.assertRaisesRegex(ValueError,'자동 매핑 불완전'):financial('TEST',{'0':{'ticker':'TEST','cik_str':123}},'Test test@example.org')
    @patch.dict(os.environ,{'FMP_API_KEY':'test-key'})
    def test_quote_mapping(self):
        with patch('secvalue.providers.get_json',return_value=[{'price':20,'marketCap':2000,'timestamp':1760000000}]):
            q=quote('TEST');self.assertEqual(q['shares'],100);self.assertEqual(q['market_cap'],2000);self.assertTrue(q['as_of'])
if __name__=='__main__':unittest.main()
