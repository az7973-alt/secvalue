import argparse,csv,io,json,os,threading,time,urllib.parse
from datetime import date
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
from .store import ROOT,connect,meta,setmeta
from .engine import analyze
from .providers import valid_ticker,csv_import,refresh,now,month_key
JOB_LOCK=threading.Lock(); JOB={'running':False,'result':None}; CACHE={}; CACHE_LOCK=threading.Lock()
def invalidate():
    with CACHE_LOCK:CACHE.clear()
def summaries():
    c=connect();version=meta(c,'data_version',meta(c,'import',{}).get('imported_at'))
    with CACHE_LOCK:
        if CACHE.get('version')==version:c.close();return CACHE['rows']
    markets={r['ticker']:json.loads(r['body']) for r in c.execute('select * from market')}
    financials={r['ticker']:json.loads(r['body']) for r in c.execute('select * from financials')}
    rates={r['cell']:r['value'] for r in c.execute('select * from rates')};rows=[]
    for r in c.execute('select * from records'):
        body=json.loads(r['body']);m=markets.get(r['ticker'],{});f=financials.get(r['ticker'],{})
        metrics=analyze(body,m,f,rates)
        # An original hardcoded price remains part of the historical workbook graph;
        # displayed current quote is separate from valuation inputs.
        rows.append({'id':r['id'],'ticker':r['ticker'],'company':r['company'],'month':r['month'],'metrics':metrics,'market':m,'financial_as_of':f.get('as_of'),'financial_source':f.get('source'),'sector':next((body['cells'].get(k,{}).get('v') for k,v in body['headers'].items() if v=='Main Category'),None)})
    c.close()
    with CACHE_LOCK:CACHE.update(version=version,rows=rows)
    return rows

def launch_refresh():
    if not JOB_LOCK.acquire(blocking=False):return False
    JOB.update(running=True,result=None)
    def run():
        try:JOB['result']=refresh();invalidate()
        except Exception:JOB['result']={'message':'갱신 중 오류. 기존 데이터는 유지됩니다. 서버 로그를 확인하세요.'}
        finally:JOB['running']=False;JOB_LOCK.release()
    threading.Thread(target=run,daemon=True).start();return True

def scheduler():
    while True:
        try:
            c=connect();enabled=meta(c,'monthly',False);last=meta(c,'last_attempt_month');n=c.execute('select count(*) from watch').fetchone()[0];c.close()
            if enabled and n and last!=month_key() and os.environ.get('FMP_API_KEY') and '@' in os.environ.get('SEC_USER_AGENT',''):launch_refresh()
        except Exception:pass
        time.sleep(30)

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def send(self,status,body,ctype='application/json; charset=utf-8',filename=None):
        if not isinstance(body,bytes):body=json.dumps(body,ensure_ascii=False,allow_nan=False).encode()
        self.send_response(status);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(body)));self.send_header('X-Content-Type-Options','nosniff');self.send_header('Cache-Control','no-store')
        if filename:self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
        self.end_headers();self.wfile.write(body)
    def do_GET(self):
        u=urllib.parse.urlparse(self.path);q=urllib.parse.parse_qs(u.query)
        try:
            if u.path=='/api/state':
                c=connect();report=meta(c,'import',{});rates=[dict(r) for r in c.execute('select * from rates')];watch=[dict(r) for r in c.execute('select * from watch order by ticker')];logs=[dict(r) for r in c.execute('select * from logs order by id desc limit 80')]
                result={'import':report,'rates':rates,'watch':watch,'logs':logs,'monthly':meta(c,'monthly',False),'last_attempt':meta(c,'last_attempt'),'job':JOB,'providers':{'market':bool(os.environ.get('FMP_API_KEY')),'sec':'@' in os.environ.get('SEC_USER_AGENT','')}};
                for w in watch:
                    for table,key in [('market','market'),('financials','financial')]:
                        record=c.execute(f'select body from {table} where ticker=?',(w['ticker'],)).fetchone()
                        w[key]=json.loads(record[0]) if record else {}
                c.close();return self.send(200,result)
            if u.path=='/api/records':return self.send(200,{'records':summaries()})
            if u.path=='/api/detail':
                c=connect();r=c.execute('select * from records where id=?',(q.get('id',[''])[0],)).fetchone()
                if not r:
                    c.close();return self.send(404,{'error':'분석 행 없음'})
                body=json.loads(r['body'])
                for table,key in [('market','latest_market'),('financials','latest_financial')]:
                    record=c.execute(f'select body from {table} where ticker=?',(r['ticker'],)).fetchone()
                    body[key]=json.loads(record[0]) if record else {}
                c.close();return self.send(200,body)
            if u.path=='/api/export.xlsx':
                from .exporter import workbook_bytes
                return self.send(200,workbook_bytes(q.get('watch',['0'])[0]=='1'),'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','secvalue-unified.xlsx')
            if u.path=='/api/export':
                c=connect();watch={r[0] for r in c.execute('select ticker from watch')};c.close();out=io.StringIO();writer=csv.writer(out)
                writer.writerow(['원본월','티커','회사','주가_USD','시가총액_USD','원본모형_내재가치_USD','기대수익률','r3','r4','r-g','금리연결','시세기준일','재무기준일','계산오류'])
                for r in summaries():
                    if q.get('watch',['0'])[0]=='1' and r['ticker'] not in watch:continue
                    m=r['metrics'];writer.writerow([r['month'],r['ticker'],r['company'],r['market'].get('price'),r['market'].get('market_cap'),m.get('value'),m.get('upside'),m.get('r3'),m.get('r4'),m.get('discount'),m['rate_linked'],r['market'].get('as_of'),r['financial_as_of'],json.dumps(m['errors'],ensure_ascii=False)])
                return self.send(200,('\ufeff'+out.getvalue()).encode(),'text/csv; charset=utf-8','secvalue-analysis.csv')
            if u.path.startswith('/api/template/'):
                kind=u.path.rsplit('/',1)[-1]
                templates={'market':'ticker,company,price,market_cap,shares,as_of\n','sec':'ticker,company,assets,equity,intangibles,revenue,receivables,inventory,liabilities,net_income,operating_income,period_start,as_of\n','rates':'cell,value,as_of\n'}
                if kind not in templates:return self.send(404,{'error':'없음'})
                return self.send(200,templates[kind].encode(),'text/csv; charset=utf-8',kind+'-template.csv')
            paths={'/':'index.html','/app.js':'app.js','/style.css':'style.css'}
            if u.path in paths:
                p=ROOT/'static'/paths[u.path];ctype={'html':'text/html','js':'text/javascript','css':'text/css'}[p.suffix[1:]]
                return self.send(200,p.read_bytes(),ctype+'; charset=utf-8')
            self.send(404,{'error':'없음'})
        except Exception as ex:self.send(500,{'error':'요청 처리 오류: '+str(ex)[:180]})
    def do_POST(self):
        # Local UI mutations must originate from the same browser origin.
        origin=self.headers.get('Origin')
        if origin and urllib.parse.urlparse(origin).netloc!=self.headers.get('Host'):return self.send(403,{'error':'다른 사이트의 요청은 허용하지 않습니다'})
        if not self.headers.get('Content-Type','').startswith('application/json'):return self.send(415,{'error':'JSON 요청이 필요합니다'})
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length>8_000_000:raise ValueError('파일 크기 제한 8MB')
            data=json.loads(self.rfile.read(length));path=urllib.parse.urlparse(self.path).path
            if path=='/api/watch':
                t=valid_ticker(data.get('ticker',''));c=connect()
                if data.get('remove'):c.execute('delete from watch where ticker=?',(t,))
                else:c.execute('insert or replace into watch values (?,?)',(t,str(data.get('name',''))[:200]))
                c.commit();c.close();return self.send(200,{'ok':True})
            if path=='/api/import':
                if JOB['running']:raise ValueError('자동 갱신 완료 후 가져오세요')
                result=csv_import(data.get('kind'),data.get('text',''));invalidate();return self.send(200,result)
            if path=='/api/monthly':
                c=connect();setmeta(c,'monthly',bool(data.get('enabled')));c.commit();c.close();return self.send(200,{'ok':True})
            if path=='/api/refresh':return self.send(202,{'started':launch_refresh()})
            self.send(404,{'error':'없음'})
        except (ValueError,TypeError,KeyError) as ex:self.send(400,{'error':str(ex)[:300]})
        except Exception:self.send(500,{'error':'저장 실패. 기존 데이터는 유지됩니다.'})

def main():
    p=argparse.ArgumentParser();p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=8000);p.add_argument('--import-workbook');p.add_argument('--update',action='store_true');args=p.parse_args()
    if args.import_workbook:
        from .importer import import_book
        print(json.dumps(import_book(args.import_workbook),ensure_ascii=False),flush=True)
    if args.update:print(json.dumps(refresh(),ensure_ascii=False));return
    c=connect();c.close();threading.Thread(target=scheduler,daemon=True).start()
    print(f'SEC Value running on port {args.port}',flush=True)
    ThreadingHTTPServer((args.host,args.port),Handler).serve_forever()
if __name__=='__main__':main()
