import json, os, sqlite3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DB = Path(os.environ.get('SECVALUE_DB', ROOT / 'data/app.sqlite3'))
def connect():
    DB.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.executescript('''
    CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY,ticker TEXT,company TEXT,month TEXT,body TEXT);
    CREATE TABLE IF NOT EXISTS market(ticker TEXT PRIMARY KEY,body TEXT);
    CREATE TABLE IF NOT EXISTS financials(ticker TEXT PRIMARY KEY,body TEXT);
    CREATE TABLE IF NOT EXISTS rates(cell TEXT PRIMARY KEY,label TEXT,value REAL,updated TEXT);
    CREATE TABLE IF NOT EXISTS watch(ticker TEXT PRIMARY KEY,name TEXT);
    CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT);
    CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY,time TEXT,kind TEXT,ticker TEXT,status TEXT,message TEXT);
    ''')
    return c

def put(c, table, ticker, body):
    if table not in ('market','financials'): raise ValueError('invalid table')
    c.execute(f'INSERT OR REPLACE INTO {table} VALUES (?,?)',(ticker,json.dumps(body,ensure_ascii=False,allow_nan=False)))

def meta(c,key,default=None):
    r=c.execute('SELECT value FROM meta WHERE key=?',(key,)).fetchone()
    return json.loads(r[0]) if r else default

def setmeta(c,key,value):
    c.execute('INSERT OR REPLACE INTO meta VALUES (?,?)',(key,json.dumps(value,ensure_ascii=False)))
