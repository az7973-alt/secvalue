import io,json,collections
from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from .store import connect,meta
from .engine import Engine,colnum,period_mismatch
from datetime import datetime,timedelta

def field_names(body):
    h=body['headers']; intangible=next((colnum(k) for k,v in h.items() if v=='Intangible assets'),30)
    net=next((colnum(k) for k,v in h.items() if v=='직전월'),39)
    final=next((colnum(k) for k,v in h.items() if v=='최종월'),51)
    years=next((colnum(k) for k,v in h.items() if v=='년수'),67)
    roa=next((colnum(k) for k,v in h.items() if v=='roa 평균'),68)
    bps=next((colnum(k) for k,v in h.items() if v=='추정 BPS'),75)
    seen=collections.Counter();out={}
    for col,label in h.items():
        n=colnum(col)
        group='기본'
        if 14<=n<intangible-2:group='자산'
        elif intangible-2<=n<intangible:group='자본'
        elif intangible<=n<net:group='재무 조정'
        elif net<=n<=final:group='순이익'
        elif final<n<=roa:group='ROA'
        elif roa<n<bps:group='배당'
        elif n>=bps:group='가치평가·분류'
        key=group+' / '+label;seen[key]+=1
        out[col]=key+(' #'+str(seen[key]) if seen[key]>1 else '')
    for col in body['cells']:
        if col not in out and col!='A':out[col]='미지정 / '+col
    return out

def workbook_bytes(watch_only=False):
    c=connect();records=[dict(r) for r in c.execute('select * from records')];watch={r[0] for r in c.execute('select ticker from watch')}
    market={r['ticker']:json.loads(r['body']) for r in c.execute('select * from market')};fin={r['ticker']:json.loads(r['body']) for r in c.execute('select * from financials')};rates={r['cell']:r['value'] for r in c.execute('select * from rates')}
    parsed=[];keys=[];seen=set()
    for r in records:
        if watch_only and r['ticker'] not in watch:continue
        b=json.loads(r['body']);names=field_names(b);parsed.append((r,b,names))
        for k in names.values():
            if k not in seen:keys.append(k);seen.add(k)
    wb=Workbook(write_only=True)
    def append(sheet,values):
        cells=[]
        for v in values:
            if isinstance(v,(dict,list)):v=json.dumps(v,ensure_ascii=False)
            if isinstance(v,str):
                cell=WriteOnlyCell(sheet,value=v);cell.data_type='s';cells.append(cell)
            else:cells.append(v)
        sheet.append(cells)
    ws=wb.create_sheet('기업분석_통합');ws.freeze_panes='D2'
    append(ws,['원본월','원본행','티커','회사','계산 오류','시세 기준일','재무 기준일']+keys)
    for r,b,names in parsed:
        e=Engine(b,market.get(r['ticker']),fin.get(r['ticker']),rates);vals={};errors=[]
        mismatch=period_mismatch(b,fin.get(r['ticker']))
        if mismatch:errors.append('기간 재정렬 필요: 새 공시와 원본 모형의 최종월 불일치')
        for col,key in names.items():
            try:
                if mismatch and b['cells'].get(col,{}).get('f'):
                    vals[key]=None
                else:
                    vals[key]=e.cell(col)
                    if b['headers'].get(col) in ('최종월','Fiscal Year') and isinstance(vals[key],(int,float)) and 10000<vals[key]<80000:
                        vals[key]=(datetime(1899,12,30)+timedelta(days=vals[key])).date().isoformat()
            except (ValueError,TypeError,OverflowError) as ex:vals[key]=None;errors.append(col+': '+str(ex))
        append(ws,[r['month'],b['row'],r['ticker'],r['company'],'; '.join(errors),market.get(r['ticker'],{}).get('as_of'),fin.get(r['ticker'],{}).get('as_of')]+[vals.get(k) for k in keys])
    ws=wb.create_sheet('기준금리');append(ws,['셀','항목','값','기준일'])
    for r in c.execute('select * from rates'):append(ws,list(r))
    ws=wb.create_sheet('Market Cap');append(ws,['ticker','company','price USD','market_cap USD','shares','as_of','source'])
    for t,m in market.items():append(ws,[t,m.get('company'),m.get('price'),m.get('market_cap'),m.get('shares'),m.get('as_of'),m.get('source')])
    ws=wb.create_sheet('SEC');append(ws,['ticker','assets','equity','intangibles','revenue','receivables','inventory','liabilities','net_income','operating_income','period_start','as_of','source'])
    for t,f in fin.items():append(ws,[t]+[f.get('cells',{}).get(k) for k in 'DEFGHIJKL']+[f.get('period_start'),f.get('as_of'),f.get('source')])
    ws=wb.create_sheet('관심종목');append(ws,['ticker','name'])
    for r in c.execute('select * from watch'):append(ws,list(r))
    ws=wb.create_sheet('안내');append(ws,['항목','내용'])
    for pair in [('형식','값 스냅샷입니다. 엑셀 안에서 자동 갱신되지 않습니다. 갱신과 계산은 웹 앱에서 실행하세요.'),('원본','data/source.xlsx 보존. 원본 월과 행 번호 보존. 같은 티커의 중복 행도 보존.'),('금리','기존 기준금리 셀 연결과 직접 입력값을 유지합니다.'),('재무금액','USD 백만 단위. 분기 실적은 동일 기간 누적값.'),('모형','역사 구간·최종월은 원본 기준입니다. 신규 분기의 완전한 모형 재작성은 별도 검증이 필요합니다.'),('원본 점검',json.dumps(meta(c,'import',{}),ensure_ascii=False))]:append(ws,pair)
    c.close();out=io.BytesIO();wb.save(out);return out.getvalue()
