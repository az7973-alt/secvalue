"""Explicit-source refreshes. Provider failure never deletes the previous snapshot."""
import csv,io,json,os,re,time,urllib.request,urllib.parse,urllib.error
from datetime import datetime,timezone,date,timedelta
from .store import connect,put,setmeta,meta

def now():return datetime.now(timezone.utc).isoformat()
def month_key():return datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m")
def get_json(url,headers=None):
    req=urllib.request.Request(url,headers={'Accept':'application/json',**(headers or {})})
    try:
        with urllib.request.urlopen(req,timeout=25) as r:return json.load(r)
    except urllib.error.HTTPError as ex:raise ValueError('데이터 제공 서버 HTTP '+str(ex.code)) from None
    except (urllib.error.URLError,TimeoutError):raise ValueError('데이터 제공 서버 연결 실패') from None

def num(x,name):
    import math
    try:v=float(x)
    except (TypeError,ValueError):raise ValueError(name+' 숫자 필요')
    if not math.isfinite(v):raise ValueError(name+' 유한한 숫자 필요')
    return v

def valid_ticker(t):
    t=str(t).strip().upper()
    if not re.fullmatch(r'[A-Z0-9][A-Z0-9.\-^=]{0,23}',t):raise ValueError('티커 형식을 확인하세요')
    return t

def csv_import(kind,text):
    rows=list(csv.DictReader(io.StringIO(text.lstrip('\ufeff'))))
    if not rows or len(rows)>15000:raise ValueError('1~15,000행의 CSV가 필요합니다')
    c=connect();count=0
    try:
        for row in rows:
            asof=row.get('as_of','').strip()
            try:date.fromisoformat(asof)
            except ValueError:raise ValueError('as_of는 YYYY-MM-DD 날짜가 필요합니다')
            if asof>date.today().isoformat():raise ValueError('미래 날짜는 입력할 수 없습니다')
            if kind=='rates':
                cell=row.get('cell','').strip()
                if not c.execute('select 1 from rates where cell=?',(cell,)).fetchone():raise ValueError('알 수 없는 금리 셀')
                v=num(row.get('value'),'value')
                if cell in ('C3','C4','C5','C6','C7','C8','C9','C13') and not -.1<=v<=1:raise ValueError('금리는 소수로 입력하세요. 예: 5%=0.05')
                if cell=='C12' and v<=0:raise ValueError('환율은 양수여야 합니다')
                c.execute('update rates set value=?,updated=? where cell=?',(v,asof,cell))
            else:
                ticker=valid_ticker(row.get('ticker',''))
                if kind=='market':
                    m={k:num(row.get(k),k) for k in ('price','market_cap','shares')}
                    if any(v<=0 for v in m.values()):raise ValueError('가격·시가총액·주식 수는 양수여야 합니다')
                    m.update(source='CSV',as_of=asof,updated_at=now(),company=row.get('company',ticker))
                    put(c,'market',ticker,m)
                elif kind=='sec':
                    names={'D':'assets','E':'equity','F':'intangibles','G':'revenue','H':'receivables','I':'inventory','J':'liabilities','K':'net_income','L':'operating_income'}
                    cells={col:num(row.get(key),key) for col,key in names.items()}
                    cells.update(B=ticker,C=row.get('company',ticker))
                    if cells['D']<0 or cells['G']<0:raise ValueError('자산·매출을 확인하세요')
                    if abs(cells['D']-cells['E']-cells['J'])>max(1,abs(cells['D'])*.01):raise ValueError('자산=부채+자본 불일치 (허용 오차 1%)')
                    start=row.get('period_start','').strip();date.fromisoformat(start)
                    if start>asof:raise ValueError('period_start는 as_of 이전이어야 합니다')
                    put(c,'financials',ticker,{'cells':cells,'source':'CSV (USD 백만 단위, 누적 실적)','as_of':asof,'period_start':start,'updated_at':now()})
                else:raise ValueError('알 수 없는 데이터 종류')
            count+=1
        c.execute('insert into logs(time,kind,ticker,status,message) values(?,?,?,?,?)',(now(),kind,'CSV','success',str(count)+'행 반영'))
        setmeta(c,'data_version',now());c.commit()
    except Exception:c.rollback();raise
    finally:c.close()
    return {'count':count}

def quote(ticker):
    key=os.environ.get('FMP_API_KEY')
    if not key:raise ValueError('FMP_API_KEY 미설정 — 시세 CSV 가져오기는 사용 가능')
    data=get_json('https://financialmodelingprep.com/stable/quote?'+urllib.parse.urlencode({'symbol':ticker,'apikey':key}))
    if not isinstance(data,list) or not data:raise ValueError('시세 응답 없음 (구독 범위·티커 확인)')
    q=data[0]; price=num(q.get('price'),'price');cap=num(q.get('marketCap'),'marketCap')
    if price<=0 or cap<=0:raise ValueError('유효하지 않은 시세')
    stamp=q.get('timestamp')
    if not isinstance(stamp,(int,float)):raise ValueError('시세 기준 시각 없음')
    return {'price':price,'market_cap':cap,'shares':cap/price,'shares_method':'시가총액/주가 (원본 엑셀과 동일)','company':q.get('name',ticker),'as_of':datetime.fromtimestamp(stamp,timezone.utc).isoformat(),'updated_at':now(),'source':'Financial Modeling Prep'}

def financial(ticker,mapping,agent):
    cik=next((str(v['cik_str']).zfill(10) for v in mapping.values() if v.get('ticker','').upper()==ticker),None)
    if not cik:raise ValueError('SEC 티커 매핑 없음 (ADR·복수 주식 종류 확인)')
    data=get_json(f'https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json',{'User-Agent':agent})
    facts=data.get('facts',{}).get('us-gaap',{})
    tags={'D':['Assets'],'E':['StockholdersEquity','StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest'],'F':['GoodwillAndIntangibleAssetsNet'],'G':['RevenueFromContractWithCustomerExcludingAssessedTax','Revenues','SalesRevenueNet'],'H':['AccountsReceivableNetCurrent'],'I':['InventoryNet'],'J':['Liabilities'],'K':['NetIncomeLoss','ProfitLoss'],'L':['OperatingIncomeLoss']}
    assets=[v for v in facts.get('Assets',{}).get('units',{}).get('USD',[]) if v.get('form') in ('10-Q','10-K') and not v.get('start') and v.get('end','')<=date.today().isoformat()]
    if not assets:raise ValueError('지원하는 USD US-GAAP 공시 없음')
    latest=max(assets,key=lambda v:(v['end'],v.get('filed','')));end=latest['end'];accn=latest['accn'];cells={'B':ticker,'C':data.get('entityName',ticker)};periods={};missing=[]
    for col,options in tags.items():
        candidates=[]
        for tag in options:
            vals=[v for v in facts.get(tag,{}).get('units',{}).get('USD',[]) if v.get('end')==end and v.get('accn')==accn]
            if col in ('G','K','L'):vals=[v for v in vals if v.get('start') and 0<(date.fromisoformat(end)-date.fromisoformat(v['start'])).days<=370]
            else:vals=[v for v in vals if not v.get('start')]
            if vals:candidates=vals;break
        if col=='F' and not candidates:
            # Do not infer zero from an absent XBRL concept.
            parts=[]
            for tag in ('Goodwill','IntangibleAssetsNetExcludingGoodwill'):
                vv=[v for v in facts.get(tag,{}).get('units',{}).get('USD',[]) if v.get('end')==end and v.get('accn')==accn and not v.get('start')]
                if vv:parts.append(vv[-1]['val'])
            if len(parts)==2:candidates=[{'val':sum(parts)}]
        if not candidates:missing.append(col);continue
        chosen=min(candidates,key=lambda v:v.get('start',end))
        cells[col]=chosen['val']/1e6
        if col in ('G','K','L'):periods[col]=chosen['start']
    if missing:raise ValueError('자동 매핑 불완전 ('+', '.join(missing)+') — 기존 자료 유지. SEC CSV로 보완하세요')
    if len(set(periods.values()))!=1:raise ValueError('매출·이익의 누적 기간 불일치 — 기존 자료 유지')
    if abs(cells['D']-cells['E']-cells['J'])>max(1,abs(cells['D'])*.01):raise ValueError('공시 자산·부채·자본 범위 불일치 — 기존 자료 유지')
    return {'cells':cells,'source':'SEC EDGAR / '+accn,'as_of':end,'period_start':periods['G'],'filed':latest.get('filed'),'updated_at':now()}

def refresh():
    c=connect();tickers=[r[0] for r in c.execute('select ticker from watch order by ticker')];out=[]
    if not tickers:c.close();return {'results':[],'message':'관심 종목을 먼저 추가하세요'}
    agent=os.environ.get('SEC_USER_AGENT','');mapping=None;mapping_error='SEC_USER_AGENT 미설정 — 앱 이름과 실제 연락 이메일이 필요합니다'
    if '@' in agent:
        try:mapping=get_json('https://www.sec.gov/files/company_tickers.json',{'User-Agent':agent})
        except ValueError as ex:mapping_error=str(ex)
    for ticker in tickers:
        for kind,table in [('market','market'),('sec','financials')]:
            try:
                if kind=='market':body=quote(ticker)
                else:
                    if mapping is None:raise ValueError(mapping_error)
                    time.sleep(.15);body=financial(ticker,mapping,agent)
                put(c,table,ticker,body);status='success';message=body['source']+' / '+str(body['as_of'])
            except (ValueError,KeyError,TypeError) as ex:status='error';message=str(ex)[:300]
            out.append({'ticker':ticker,'kind':kind,'status':status,'message':message})
            c.execute('insert into logs(time,kind,ticker,status,message) values(?,?,?,?,?)',(now(),kind,ticker,status,message))
            c.commit()
    setmeta(c,'last_attempt_month',month_key());setmeta(c,'last_attempt',now());setmeta(c,'data_version',now());c.commit();c.close()
    return {'results':out,'message':'갱신 완료. 금리는 기준금리 표의 연결값을 사용합니다.'}
