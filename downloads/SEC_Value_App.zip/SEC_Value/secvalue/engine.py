"""Small, non-eval formula interpreter for the workbook's valuation graph.
Unsupported formulas use original cached values, explicitly reported in status.
"""
import math,re
from datetime import datetime,timedelta
from functools import lru_cache
from openpyxl.formula.tokenizer import Tokenizer
class FormulaError(ValueError): pass
@lru_cache(maxsize=20000)
def parse(formula):
    ts=[t for t in Tokenizer(formula).items if t.type!='WHITE-SPACE']; pos=0
    precedence={'=':1,'<>':1,'<':1,'>':1,'<=':1,'>=':1,'&':2,'+':3,'-':3,'*':4,'/':4,'^':5}
    def expr(minp=0):
        nonlocal pos
        if pos>=len(ts):raise FormulaError('수식 누락')
        t=ts[pos];pos+=1
        if t.type=='OPERATOR-PREFIX': left=('unary',t.value,expr(6))
        elif t.type=='FUNC' and t.subtype=='OPEN':
            args=[]
            if pos<len(ts) and not(ts[pos].type=='FUNC' and ts[pos].subtype=='CLOSE'):
                while True:
                    args.append(expr())
                    if pos<len(ts) and ts[pos].type=='SEP':pos+=1;continue
                    break
            if pos>=len(ts) or ts[pos].subtype!='CLOSE':raise FormulaError('함수 괄호')
            pos+=1;left=('call',t.value[:-1].upper(),args)
        elif t.type=='PAREN' and t.subtype=='OPEN':
            left=expr()
            if pos>=len(ts) or ts[pos].subtype!='CLOSE':raise FormulaError('괄호')
            pos+=1
        elif t.type=='OPERAND':
            if t.subtype=='NUMBER':left=('literal',float(t.value))
            elif t.subtype=='LOGICAL':left=('literal',t.value=='TRUE')
            elif t.subtype=='TEXT':left=('literal',t.value[1:-1].replace('""','"'))
            elif t.subtype=='ERROR':left=('error',t.value)
            else:left=('ref',t.value)
        else:raise FormulaError('지원하지 않는 토큰 '+t.value)
        while pos<len(ts):
            op=ts[pos]
            if op.type=='OPERATOR-POSTFIX' and op.value=='%':pos+=1;left=('binary','/',left,('literal',100));continue
            p=precedence.get(op.value,-1) if op.type=='OPERATOR-INFIX' else -1
            if p<minp:break
            pos+=1; right=expr(p if op.value=='^' else p+1);left=('binary',op.value,left,right)
        return left
    result=expr()
    if pos!=len(ts):raise FormulaError('지원하지 않는 수식')
    return result

def colnum(col):
    n=0
    for ch in col:n=n*26+ord(ch)-64
    return n

def colname(n):
    s=''
    while n:n,r=divmod(n-1,26);s=chr(65+r)+s
    return s

def flatten(xs):
    for x in xs:
        if isinstance(x,list):yield from flatten(x)
        else:yield x

class Engine:
    def __init__(self,body,market,financial,rates):
        self.body=body;self.cells=body['cells'];self.market=market or {};self.financial=financial or {};self.rates=rates
        self.cache={};self.active=set();self.fallback=set()
    def cell(self,col):
        if col in self.cache:
            if isinstance(self.cache[col],Exception):raise self.cache[col]
            return self.cache[col]
        if col in self.active:raise FormulaError('순환 참조')
        self.active.add(col)
        try:
            c=self.cells.get(col,{})
            if c.get('error'):raise FormulaError(str(c.get('v')))
            f=c.get('f');v=c.get('v')
            # Original array formulas locate historical start dates. Retain date serials;
            # no arbitrary cached fallback is used for valuation arithmetic.
            if f and ('INDEX(' in f or 'MATCH(' in f or '_xlfn.' in f):
                if v is None:raise FormulaError('기준일 캐시 없음')
                self.fallback.add(col);result=v
            elif f:
                canonical=re.sub(r'(?<![A-Za-z0-9_!$])(\$?[A-Z]{1,3}\$?)'+str(self.body['row'])+r'(?![0-9])',r'\g<1>0',f)
                result=self.run(parse(canonical))
            else:result=v
            if isinstance(result,float) and not math.isfinite(result):raise FormulaError('유효하지 않은 계산값')
            self.cache[col]=result;return result
        except (FormulaError,ValueError,TypeError,OverflowError) as ex:
            self.cache[col]=ex
            raise
        finally:self.active.remove(col)
    def ref(self,s):
        s=s.replace('$','')
        if '!' in s:
            sheet,addr=s.rsplit('!',1);sheet=sheet.strip("'")
            if sheet=='기준금리':
                if addr not in self.rates:raise FormulaError('금리 누락: '+addr)
                return self.rates[addr]
            raise FormulaError('지원하지 않는 외부 참조: '+sheet)
        if ':' in s:
            a,b=s.split(':'); ma=re.fullmatch(r'([A-Z]+)(\d+)',a);mb=re.fullmatch(r'([A-Z]+)(\d+)',b)
            if not ma or not mb or ma[2]!=mb[2]:raise FormulaError('지원하지 않는 범위')
            if int(ma[2]) not in (0,self.body['row']):raise FormulaError('다른 행 참조')
            return [self.cell(colname(i)) for i in range(colnum(ma[1]),colnum(mb[1])+1)]
        m=re.fullmatch(r'([A-Z]+)(\d+)',s)
        if not m or int(m[2]) not in (0,self.body['row']):raise FormulaError('다른 행/외부 참조')
        return self.cell(m[1])
    @staticmethod
    def number(v):
        if v is None:return 0
        if not isinstance(v,(int,float)):raise FormulaError('숫자가 아닌 값')
        return v
    def run(self,node):
        typ=node[0]
        if typ=='literal':return node[1]
        if typ=='error':raise FormulaError(node[1])
        if typ=='ref':return self.ref(node[1])
        if typ=='unary':return (-1 if node[1]=='-' else 1)*self.number(self.run(node[2]))
        if typ=='binary':
            op=node[1];a=self.run(node[2]);b=self.run(node[3])
            if op=='&':return str(a)+str(b)
            a=self.number(a);b=self.number(b)
            try:
                if op=='+':return a+b
                if op=='-':return a-b
                if op=='*':return a*b
                if op=='/':return a/b
                if op=='^':
                    r=a**b
                    if isinstance(r,complex):raise FormulaError('복소수 계산')
                    return r
                return {'=':lambda:a==b,'<>':lambda:a!=b,'<':lambda:a<b,'>':lambda:a>b,'<=':lambda:a<=b,'>=':lambda:a>=b}[op]()
            except (ZeroDivisionError,OverflowError) as e:raise FormulaError(str(e))
        name,args=node[1:]
        if name=='IF':return self.run(args[1] if self.run(args[0]) else args[2])
        if name=='IFERROR':
            try:return self.run(args[0])
            except (FormulaError,ValueError,TypeError):return self.run(args[1])
        if name=='VLOOKUP':
            ref=args[1][1]; index=int(self.run(args[2]));sheet,area=ref.rsplit('!',1);sheet=sheet.strip("'")
            start=re.sub('[^A-Z]','',area.split(':')[0]);column=colname(colnum(start)+index-1)
            if sheet=='Market Cap':
                m=self.market; mapping={'C':m.get('ticker'),'D':m.get('company'),'E':m.get('price'),'F':m.get('market_cap')/1000 if isinstance(m.get('market_cap'),(int,float)) else None,'G':m.get('shares'),'I':m.get('market_cap')*self.rates.get('C12',0)/1e8 if isinstance(m.get('market_cap'),(int,float)) else None}
                result=mapping.get(column)
            elif sheet.startswith('SEC('):result=self.financial.get('cells',{}).get(column,0) if self.financial else None
            else:raise FormulaError('알 수 없는 조회 대상')
            if result is None:raise FormulaError('조회값 없음: '+sheet+' '+column)
            return result
        vals=list(flatten([self.run(a) for a in args]));nums=[x for x in vals if isinstance(x,(int,float))]
        if name=='SUM':return sum(nums)
        if name=='AVERAGE':
            if not nums:raise FormulaError('평균 대상 없음')
            return sum(nums)/len(nums)
        if name=='MIN':return min(nums)
        if name=='EXP':return math.exp(self.number(vals[0]))
        if name in ('YEAR','MONTH'):
            v=vals[0]
            if isinstance(v,str) and re.fullmatch(r'\d{4}-\d{2}',v):dt=datetime.strptime(v,'%Y-%m')
            else:dt=datetime(1899,12,30)+timedelta(days=self.number(v))
            return dt.year if name=='YEAR' else dt.month
        raise FormulaError('지원하지 않는 함수 '+name)

def period_mismatch(body,financial):
    if not (financial or {}).get('as_of'):return False
    col=next((k for k,v in body['headers'].items() if v=='최종월'),None)
    original=body['cells'].get(col,{}).get('v')
    if not isinstance(original,(int,float)):return True
    end=(datetime(1899,12,30)+timedelta(days=original)).date().isoformat()
    return financial['as_of'][:10]!=end

def analyze(body,market,financial,rates):
    if period_mismatch(body,financial):
        return {'value':None,'upside':None,'price':(market or {}).get('price'),'errors':{'value':'기간 재정렬 필요: 새 공시와 원본 모형의 최종월이 다릅니다'},'retained_date_cells':[],'rate_linked':body['rate_linked'],'period_mismatch':True}
    e=Engine(body,market,financial,rates);headers=body['headers'];result={};errors={}
    wanted={'추정 BPS':'bps','수정 BPS':'adjusted_bps','추정 EPS':'eps','수정 EPS':'adjusted_eps','ROE':'roe','r3':'r3','r4':'r4','r-g':'discount','Value':'value','주가($)':'price','기대수익률':'upside','PER':'pe','PBR':'pb','roa 평균':'roa','자산가치':'asset_value','수익가치':'earnings_value','성장가치':'growth_value'}
    for col,label in headers.items():
        if label not in wanted:continue
        try:result[wanted[label]]=e.cell(col)
        except (FormulaError,ValueError,TypeError,OverflowError) as ex:result[wanted[label]]=None;errors[wanted[label]]=str(ex)
    result.update(errors=errors,retained_date_cells=sorted(e.fallback),rate_linked=body['rate_linked'])
    return result
