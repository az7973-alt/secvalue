"""Read workbook XML once, preserving cached values AND original formulas. No workbook writes."""
import json, re, zipfile, posixpath
from datetime import datetime,timezone
from xml.etree import ElementTree as E
from openpyxl.formula.translate import Translator
from .store import connect,put,setmeta
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
MONTHS='JAN FEB MAR APR MAY JUN JUL AUG SEP OCT NOV DEC'.split()
def read_book(path):
    with zipfile.ZipFile(path) as z:
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            root=E.fromstring(z.read('xl/sharedStrings.xml'))
            strings=[''.join(x.itertext()) for x in root]
        rel=E.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        targets={x.attrib['Id']:posixpath.normpath(posixpath.join('xl',x.attrib['Target'])) if not x.attrib['Target'].startswith('/') else x.attrib['Target'].lstrip('/') for x in rel}
        wb=E.fromstring(z.read('xl/workbook.xml'))
        for s in wb.find('s:sheets',NS):
            rid=s.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
            root=E.fromstring(z.read(targets[rid])); rows={}; shared={}
            for row in root.findall('s:sheetData/s:row',NS):
                cells={}
                for cell in row:
                    address=cell.attrib['r']; col=re.sub(r'\d','',address)
                    v=cell.find('s:v',NS); value=v.text if v is not None else None
                    typ=cell.attrib.get('t')
                    if typ=='s' and value is not None: value=strings[int(value)]
                    elif typ=='inlineStr': value=''.join(cell.find('s:is',NS).itertext())
                    elif value is not None and typ not in ('str','e'):
                        try: value=float(value); value=int(value) if value.is_integer() else value
                        except ValueError: pass
                    f=cell.find('s:f',NS); formula=None
                    if f is not None:
                        formula='='+f.text if f.text else None
                        if f.attrib.get('t')=='shared':
                            si=f.attrib['si']
                            if formula: shared[si]=(address,formula)
                            elif si in shared:
                                origin,base=shared[si]
                                formula=Translator(base,origin=origin).translate_formula(address)
                    if value is not None or formula: cells[col]={'v':value,'f':formula,'error':typ=='e'}
                rows[int(row.attrib['r'])]=cells
            yield s.attrib['name'],rows

def import_book(path):
    c=connect()
    if c.execute('SELECT count(*) FROM records').fetchone()[0]:
        return {'existing':True,'records':c.execute('SELECT count(*) FROM records').fetchone()[0]}
    counts={}; errors=0; rate_refs=0; manual=0
    for name,rows in read_book(path):
        if name in MONTHS:
            headers={col:str(v['v']).strip() for col,v in rows.get(2,{}).items() if v['v'] is not None}
            count=0
            for rn,cells in rows.items():
                if rn<3: continue
                ticker=cells.get('B',{}).get('v'); company=cells.get('C',{}).get('v')
                if not isinstance(ticker,str) or not ticker.strip() or not isinstance(company,str): continue
                ticker=ticker.strip().upper()
                if ticker in ('TICKER','TOTAL') or ticker.startswith('#'): continue
                errors+=sum(bool(x.get('error') or '#REF!' in (x.get('f') or '')) for x in cells.values())
                linked=any('기준금리!' in (x.get('f') or '') for x in cells.values())
                rate_refs+=linked; manual+=not linked
                body={'row':rn,'sheet':name,'headers':headers,'cells':cells,'rate_linked':linked}
                c.execute('INSERT INTO records VALUES (?,?,?,?,?)',(f'{name}:{rn}',ticker,company,name,json.dumps(body,ensure_ascii=False)))
                count+=1
            counts[name]=count
        elif name=='Market Cap':
            for rn,cells in rows.items():
                ticker=cells.get('C',{}).get('v')
                if rn<3 or not isinstance(ticker,str): continue
                put(c,'market',ticker.strip().upper(),{'price':cells.get('E',{}).get('v'),'market_cap':(cells.get('F',{}).get('v') or 0)*1000,'shares':cells.get('G',{}).get('v'),'company':cells.get('D',{}).get('v'),'source':'원본 엑셀','as_of':None})
        elif name.startswith('SEC('):
            for rn,cells in rows.items():
                ticker=cells.get('B',{}).get('v')
                if rn<3 or not isinstance(ticker,str):continue
                put(c,'financials',ticker.strip().upper(),{'cells':{k:v['v'] for k,v in cells.items()},'source':name,'as_of':None})
        elif name=='기준금리':
            for rn,cells in rows.items():
                v=cells.get('C',{}).get('v'); label=cells.get('B',{}).get('v')
                if isinstance(v,(float,int)):
                    c.execute('INSERT INTO rates VALUES (?,?,?,?)',(f'C{rn}',str(label),v,'원본: '+str(rows.get(1,{}).get('B',{}).get('v',''))))
    report={'sheets':counts,'records':sum(counts.values()),'source_errors':errors,'rate_linked':rate_refs,'rate_manual':manual,'imported_at':datetime.now(timezone.utc).isoformat(),'filename':str(path).split('/')[-1]}
    setmeta(c,'import',report);c.commit();c.close();return report
